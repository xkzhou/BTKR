# BTKR
Biostatistics tools kit in R
This package contains a few R functions for efficient exploratory analyses of the data.
